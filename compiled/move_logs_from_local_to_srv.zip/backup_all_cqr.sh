#!/bin/bash

username="cqrlog"
password="oh1kh"
server="localhost"
port="3306"

clear
echo "This script backups all logs from external database using mysqldump"
echo "and also copies ~/.config/cqrlog folder to folder zip file to make 100%"
echo "full backup from your Cqrlog."
echo
echo "Store directory zip and all database dumps from /tmp to safe place!"
echo "You need to edit this script at beginning if your database uses different"
echo "username and password than '$username' and '$password'"
echo "and/or different SQL server than '$server' and port '$port'"
echo
echo "All checked and OK. Start the job!"
echo "(enter to continue, ctrl+C to stop for editing script values)"
read a

stamp=$(date +_%Y%m%d-%H%M)
echo -e "\nStarted$stamp with zip"
echo -e "Creating zip file /tmp/cqrfolder.zip from ~/.config/cqrlog folder\n"
zip -qdgr9 /tmp/cqrfolder.zip /home/$USER/.config/cqrlog
echo -e "To restore from zip file use command:\n unzip /tmp/cqrfolder.zip -d /" 

echo -e "\nSQL dump follows:\n"
echo -e "Creating common backup of all CQRLOG logs in database:\n/tmp/allcqrlogs$stamp.sql\n"
$(mysql -u$username -p$password -B -N -h$server -P$port -e " show databases like 'cqr%'" |\
xargs  echo -n mysqldump -q -h$server -P$port  -u$username -p$password --databases) > /tmp/allcqrlogs$stamp.sql
echo -e "Creating separate backups of each CQRLOG logXXX in database:"
mysql  -u$username -p$password -B -N -h$server -P$port -e " show databases like 'cqr%'" |\
xargs -d\ | while read line; do if [[ $line != "" ]];then\
 echo -e "echo /tmp/$line$stamp.sql\nmysqldump -q -h$server -P$port  -u$username -p$password $line > /tmp/$line$stamp.sql\n";fi;done > /tmp/sepsql.sh
chmod a+x /tmp/sepsql.sh
/tmp/sepsql.sh
rm /tmp/sepsql.sh

echo -e "\nDone!\nCopy backup files to your safe place.\nThey will be erased from /tmp at next Linux start\n\n"
echo "To restore all CQRLOG logs use command:"
echo -e "mysql -h$server -P$port  -u$username -p$password < /tmp/allcqrlogs$stamp.sql\n\n"
echo "To restore single a log use command:"
echo "mysql -h$server -P$port  -u$username -p$password cqrlog001 < /tmp/cqrlog001$stamp.sql"
echo -e "\nBe sure that both log numbers used in line are equal\n"
