#!/bin/bash

username="cqrlog"
password="cqrlog"
server="localhost"
port="3306"

clear
echo "This script backups all logs from 'save log data to local machine' using mysqldump"
echo "You can then restore log dumps to external server."
echo
echo "Cqrlog must be running when this script is used."
echo
echo "All OK. Start the job!"
echo "(enter to continue, ctrl+C to stop for editing script values)"
read a

stamp=$(date +_%Y%m%d-%H%M)

echo -e "\nSQL dump follows:\n"
echo -e "Creating common backup of all CQRLOG logs in database:\n/tmp/allcqrlogs$stamp.sql\n"
$(mysql -S/home/$USER/.config/cqrlog/database/sock -B -N -e " show databases like 'cqr%'" |\
xargs  echo -n mysqldump -q  -S/home/$USER/.config/cqrlog/database/sock --databases) > /tmp/allcqrlogs$stamp.sql
if [ $? -ne "0" ]
 then
  echo -e "\n\nIs Cqrlog running with 'save log data to local machine'? CHECK!\n"
  exit
 fi
echo -e "Creating separate backups of each CQRLOG logXXX in database:"
mysql   -S/home/$USER/.config/cqrlog/database/sock -B -N -e " show databases like 'cqr%'" |\
xargs -d\ | while read line; do if [[ $line != "" ]];then\
 echo -e "echo /tmp/$line$stamp.sql\nmysqldump -q  -S/home/$USER/.config/cqrlog/database/sock $line > /tmp/$line$stamp.sql\n";fi;done > /tmp/sepsql.sh
chmod a+x /tmp/sepsql.sh
/tmp/sepsql.sh
rm /tmp/sepsql.sh

echo -e "\nDone!\nCopy backup files to your safe place.\nThey will be erased from /tmp at next Linux start\n\n"
echo "To restore all CQRLOG logs to external server use command:"
echo -e "mysql -h$server -P$port  -u$username -p$password < /tmp/allcqrlogs$stamp.sql\n\n"
echo "To restore single a log to external server use command:"
echo "mysql -h$server -P$port  -u$username -p$password cqrlog001 < /tmp/cqrlog001$stamp.sql"
echo -e "\nBe sure that both log numbers used in line are equal\n"
